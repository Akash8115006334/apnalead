function ApnaLeadEnquiryForm(AuthenticationKey) {
  const enquiryFormHTML = `
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css">
<style>
.rounded {
  -o-border-radius: 1rem;
  -ms-border-radius: 1rem;
  -webkit-border-radius: 1rem;
  -moz-border-radius: 1rem;
  border-radius: 1rem !important;
} 
.enquiry-btn {
  border-radius: 1rem;
  color: white;
  text-decoration: none;
  font-size: 1.4rem !important;
  position: fixed;
  right: 0px;
  top: 35%;
  transform: rotate(180deg);
  cursor: pointer;
}
.enquiry-btn img {
  width: 30%;
}
.enquiry-btn:hover {
  color: white;
  text-decoration: underline;
}
#enquiry-form {
  position: fixed;
  width: 100%;
  top: 0px;
  right: 0px;
  background-color: #0000008f;
  height: 100%;
  overflow-y: scroll;
  z-index:9999;
}

#enquiry-form .div {
  min-width: 320px;
  max-width: 480px;
  background-color: white;
  border-radius: 1rem;
  padding: 1rem;
  margin: 2% auto;
}

</style>
  <a id='EnquiryBtn' class="enquiry-btn">
    <img src="https://www.pngkey.com/png/full/255-2555375_stg-travel-special-offers-quick-enquiry-vertical-button.png">
  </a>
  <section id='enquiry-form' style='display:none;'>
    <div class="div">
      <div id='FormArea'>
        <form method="POST" id="LeadForm">
        <input type='text' hidden id='AuthKey' name='AuthenticationKey'>
          <div class="form-group text-center" style='margin-bottom:0.5rem !important;'>
            <h2>Have an eqnuiry?</h2>
            <p>Feel free to share your enquiry...</p>
          </div>
          <div class="form-group" style='margin-bottom:1rem !important;'>
            <label>Enter Full Name</label>
            <input type="text" name='FullName' required class="form-control">
          </div>
          <div class="form-group" style='margin-bottom:1rem !important;'>
            <label>Enter Phone Number</label>
            <input type="text" minlength="10" maxlength="12" name='PhoneNumber' required class="form-control" placeholder="without +91">
          </div>
          <div class="form-group" style='margin-bottom:1rem !important;'>
            <label>Enter EmailId</label>
            <input type="email" name='EmailId' required class="form-control">
          </div>
          <div class="form-group" style='margin-bottom:1rem !important;'>
            <label>Requirement For</label>
            <select name='Requirement' required='' id='ProjectList' class="form-control">
             
            </select>
          </div>
          <div class="form-group" style='margin-bottom:1rem !important;'>
            <label>Enter Query Details</label>
            <textarea class="form-control" required rows="3" name="Message"></textarea>
          </div>
          <div class="form-group" style='display:flex !important;justify-content:end !important;align-items:center !important;'>
            <button name="btn" class="btn btn-md btn-success" style='margin:0.5rem;'>Save Details</button>
            <a id='CloseEnquiryBtn'  type='button'  style='margin:0.5rem;margin-top:0.6rem;box-shadow:0px 0px 2px red !important' class="btn btn-md btn-default shadow-sm">Cancel</a>
          </div>
        </form>
      </div>
      <div id='ThankMsg' style='display:none;'>
        <div class="text-center p-3">
          <h1 class="text-success">Thanking you!</h1>
          <p style='margin-bottom:1rem !important;'>We have received your enquiry and will contact you as soon as possible.</p>
          <a href="" class="btn btn-sm btn-info" style='color:white !important;'>Back to Home</a>
        </div>
      </div>
    </div>
  </section>
`;

  //initiate enquiry form
  document.getElementById("MainEnquiryForm").innerHTML = enquiryFormHTML;
  document.getElementById("AuthKey").value = AuthenticationKey;

  //ajax request
  //ajax for GOOGLE SHEET TO APNA LEAD

  let ProjectList = document.getElementById("ProjectList");
 document.addEventListener("DOMContentLoaded", function () {

  // Make the GET request
  fetch("https://app.apnalead.com/api/GenerateProjectResponse.php?GetProjectOptions=true&ProjectFroAuthenticationKey=" + AuthenticationKey)
    .then(response => response.text())
    .then(function (response) {
      // Handle the response
      document.getElementById("ProjectList").innerHTML = response;
    })
    .catch(function (error) {
      // Handle errors
      document.getElementById("ProjectList").innerHTML = "<option value='0'>No Project Found</option>";
    });
});



  //variables
  let url =
    "https://script.google.com/macros/s/AKfycbzZ5-IOOzaTc7PwbtJlrz_P5G5W88TR8qv1i9s-R4qDZh5K-T6dsJGjPufIl1Zb7atQ3w/exec";
  let LeadForm = document.getElementById("LeadForm");
  let FormArea = document.getElementById("FormArea");
  let ThankMsg = document.getElementById("ThankMsg");

  //show html from js
  // You can now use the "enquiryFormHTML" variable wherever needed in your JavaScript code.

  // JavaScript to show/hide the div on click
  document.getElementById("EnquiryBtn").addEventListener("click", function () {
    var EnquiryForm = document.getElementById("enquiry-form");
    if (EnquiryForm.style.display === "none") {
      EnquiryForm.style.display = "block";
    } else {
      EnquiryForm.style.display = "none";
    }
  });

  // JavaScript to show/hide the div on click
  document
    .getElementById("CloseEnquiryBtn")
    .addEventListener("click", function () {
      var EnquiryForm = document.getElementById("enquiry-form");
      if (EnquiryForm.style.display === "none") {
        EnquiryForm.style.display = "block";
      } else {
        EnquiryForm.style.display = "none";
      }
    });

  //save HTML form data into Google Sheets
  LeadForm.addEventListener("submit", (e) => {
    e.target.btn.innerHTML = "Sending. Please wait...";
    let LeadFormData = new FormData(LeadForm);
    fetch(url, {
      method: "POST",
      body: LeadFormData,
    })
      .then((res) => res.text())
      .then((finalRes) => {
        e.target.btn.innerHTML = "Submit";
        FormArea.style.display = "none";
        ThankMsg.style.display = "Block";
      });
    e.preventDefault();
  });
}
