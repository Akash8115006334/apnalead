<div>
  <a href="index.php" class="btn btn-sm btn-info">System Profile</a>
  <a href="advance-settings.php" class="btn btn-sm btn-info">Advance Settings</a>
  <a href="app-config.php" class="btn btn-sm btn-info">App Configurations</a>
  <a href="data-counters.php" class="btn btn-sm btn-info">Data Counters</a>
  <a href="integrations.php" class="btn btn-sm btn-info">Integrations</a>
  <a href="webhook.php" class="btn btn-sm btn-info">Web-Hook</a>
</div>