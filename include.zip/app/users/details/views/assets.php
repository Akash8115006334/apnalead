<div class="row">
    <div class="col-md-12">
        <h6 class="app-sub-heading">All Assets</h6>
    </div>
</div>