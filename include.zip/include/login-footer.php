<div class="text-gray-600 text-center">
  <p class="small mb-3">
    Copyrighted &copy; <?php echo date("Y"); ?> & Rights are reserved by <a class='text-primary' href="<?php echo DEVELOPER_URL; ?>" target="_blank"><?php echo APP_NAME; ?></a>
  </p>
</div>