<div class="preloader flex-column justify-content-center align-items-center" id="loader">
  <img style="box-shadow:0px 0px 0px !important;" class="animation__shake" src="<?php echo APP_LOGO; ?>" alt="<?php echo APP_NAME; ?>" height="90" width="90">
</div>