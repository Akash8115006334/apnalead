<?php
require '../require/modules.php';

header("location:" . DOMAIN);
