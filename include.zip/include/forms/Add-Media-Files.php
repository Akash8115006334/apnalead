<section class="pop-section hidden" id="Add-Media-Files">
    <div class="action-window">
        <div class='container'>
            <div class='row'>
                <div class='col-md-12'>
                    <h4 class='app-heading'>Add New Counters</h4>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="pop-section hidden" id="Success">
    <div class="action-window">
        <div ckass="container"></div>
    </div>
</section>
<section class="pop-section hidden" id="failed">
    <div class="action-window">

    </div>
</section>