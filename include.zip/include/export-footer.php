<div class="company-details">
 <hr class="lh-1-3 bg-dark">
 <p class="lh-1-3 text-grey text-center fs-12">
  this is auto generated!
 </p>
</div>